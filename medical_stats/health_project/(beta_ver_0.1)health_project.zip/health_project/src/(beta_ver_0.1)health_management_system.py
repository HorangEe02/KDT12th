"""
건강 상태 체크 & 관리 시스템
- BMI 계산 및 비만도 측정
- 혈압 체크 및 상태 분석
- 건강 기록 저장 (날짜별 파일 저장)
- 히스토리 조회
- 건강 조언 출력
"""

import os
from datetime import datetime


class HealthData:
    """건강 데이터를 저장하는 클래스"""

    def __init__(self, name, height, weight, systolic, diastolic, date=None):
        self.name = name
        self.height = height  # cm
        self.weight = weight  # kg
        self.systolic = systolic  # 수축기 혈압
        self.diastolic = diastolic  # 이완기 혈압
        self.date = date if date else datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def calculate_bmi(self):
        """BMI 계산 (체중(kg) / (신장(m)^2))"""
        height_m = self.height / 100
        bmi = self.weight / (height_m ** 2)
        return round(bmi, 2)

    def get_bmi_status(self):
        """BMI 기준 비만도 판정"""
        bmi = self.calculate_bmi()

        if bmi < 18.5:
            return "저체중"
        elif bmi < 23:
            return "정상"
        elif bmi < 25:
            return "과체중"
        elif bmi < 30:
            return "비만 1단계"
        elif bmi < 35:
            return "비만 2단계"
        else:
            return "비만 3단계 (고도비만)"

    def get_blood_pressure_status(self):
        """혈압 상태 분석"""
        systolic = self.systolic
        diastolic = self.diastolic

        if systolic < 90 or diastolic < 60:
            return "저혈압"
        elif systolic < 120 and diastolic < 80:
            return "정상"
        elif systolic < 130 and diastolic < 85:
            return "주의 (정상 고혈압)"
        elif systolic < 140 or diastolic < 90:
            return "고혈압 전단계"
        elif systolic < 160 or diastolic < 100:
            return "고혈압 1단계"
        elif systolic < 180 or diastolic < 110:
            return "고혈압 2단계"
        else:
            return "고혈압 3단계 (위험)"

    def get_health_advice(self):
        """건강 상태에 따른 맞춤 조언"""
        bmi_status = self.get_bmi_status()
        bp_status = self.get_blood_pressure_status()

        advice = []

        # BMI 기반 조언
        if bmi_status == "저체중":
            advice.append("- 규칙적인 식사와 영양가 있는 음식 섭취를 권장합니다.")
            advice.append("- 근력 운동을 통해 건강한 체중 증가를 목표로 하세요.")
        elif bmi_status == "정상":
            advice.append("- 현재 체중을 잘 유지하고 계십니다. 계속 유지하세요!")
            advice.append("- 규칙적인 운동과 균형잡힌 식습관을 유지하세요.")
        elif bmi_status == "과체중":
            advice.append("- 주 3-4회, 30분 이상 유산소 운동을 권장합니다.")
            advice.append("- 칼로리 섭취를 조절하고 채소 위주 식단을 늘려보세요.")
        else:  # 비만
            advice.append("- 의료 전문가와 상담하여 체계적인 체중 관리 계획을 세우세요.")
            advice.append("- 규칙적인 운동과 식단 조절이 필요합니다.")
            advice.append("- 급격한 다이어트보다 꾸준한 생활습관 개선이 중요합니다.")

        # 혈압 기반 조언
        if bp_status == "저혈압":
            advice.append("- 충분한 수분 섭취와 적절한 염분 섭취가 필요합니다.")
            advice.append("- 증상이 지속되면 의료 전문가와 상담하세요.")
        elif bp_status == "정상":
            advice.append("- 혈압이 정상 범위입니다. 건강한 생활을 유지하세요!")
        elif "주의" in bp_status or "전단계" in bp_status:
            advice.append("- 염분 섭취를 줄이고 규칙적인 운동을 시작하세요.")
            advice.append("- 정기적으로 혈압을 측정하고 관리하세요.")
        else:  # 고혈압
            advice.append("- 즉시 의료 전문가와 상담하여 치료 계획을 세우세요.")
            advice.append("- 저염식, 금연, 절주가 필수입니다.")
            advice.append("- 스트레스 관리와 충분한 수면이 중요합니다.")

        return "\n".join(advice)

    def to_string(self):
        """저장용 문자열 형식으로 변환"""
        return f"{self.date}|{self.name}|{self.height}|{self.weight}|{self.systolic}|{self.diastolic}"

    @staticmethod
    def from_string(data_str):
        """문자열에서 HealthData 객체 생성"""
        parts = data_str.strip().split("|")
        if len(parts) == 6:
            return HealthData(
                name=parts[1],
                height=float(parts[2]),
                weight=float(parts[3]),
                systolic=int(parts[4]),
                diastolic=int(parts[5]),
                date=parts[0]
            )
        return None


class HealthManager:
    """건강 관리 시스템 메인 클래스"""

    def __init__(self):
        self.data_dir = "health_records"
        self.ensure_data_directory()

    def ensure_data_directory(self):
        """데이터 저장 디렉토리가 없으면 생성"""
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
            print(f"[시스템] '{self.data_dir}' 디렉토리를 생성했습니다.\n")

    def input_health_data(self):
        """사용자로부터 건강 데이터 입력받기"""
        print("\n" + "="*50)
        print("       건강 데이터 입력")
        print("="*50)

        try:
            name = input("이름: ")
            height = float(input("키 (cm): "))
            weight = float(input("몸무게 (kg): "))
            systolic = int(input("수축기 혈압 (mmHg): "))
            diastolic = int(input("이완기 혈압 (mmHg): "))

            # 유효성 검사
            if height <= 0 or weight <= 0:
                print("\n[오류] 키와 몸무게는 0보다 커야 합니다.")
                return None

            if systolic <= 0 or diastolic <= 0:
                print("\n[오류] 혈압 값은 0보다 커야 합니다.")
                return None

            if systolic <= diastolic:
                print("\n[오류] 수축기 혈압이 이완기 혈압보다 높아야 합니다.")
                return None

            return HealthData(name, height, weight, systolic, diastolic)

        except ValueError:
            print("\n[오류] 올바른 숫자를 입력해주세요.")
            return None

    def display_analysis(self, health_data):
        """건강 데이터 분석 결과 출력"""
        print("\n" + "="*50)
        print("       건강 상태 분석 결과")
        print("="*50)
        print(f"이름: {health_data.name}")
        print(f"날짜: {health_data.date}")
        print("-" * 50)

        # BMI 분석
        bmi = health_data.calculate_bmi()
        bmi_status = health_data.get_bmi_status()
        print(f"\n[BMI 분석]")
        print(f"  BMI 지수: {bmi}")
        print(f"  비만도: {bmi_status}")

        # 혈압 분석
        bp_status = health_data.get_blood_pressure_status()
        print(f"\n[혈압 분석]")
        print(f"  수축기/이완기: {health_data.systolic}/{health_data.diastolic} mmHg")
        print(f"  상태: {bp_status}")

        # 건강 조언
        print(f"\n[건강 조언]")
        print(health_data.get_health_advice())
        print("=" * 50)

    def save_record(self, health_data):
        """건강 기록을 날짜별 파일로 저장"""
        date_str = datetime.now().strftime("%Y%m%d")
        filename = os.path.join(self.data_dir, f"health_{date_str}.txt")

        try:
            with open(filename, "a", encoding="UTF-8") as f:
                f.write(health_data.to_string() + "\n")
            print(f"\n[저장 완료] {filename}에 기록이 저장되었습니다.")
            return True
        except Exception as e:
            print(f"\n[저장 실패] 오류: {e}")
            return False

    def view_history(self):
        """저장된 건강 기록 히스토리 조회"""
        print("\n" + "="*50)
        print("       건강 기록 히스토리")
        print("="*50)

        # 저장된 파일 목록 가져오기
        if not os.path.exists(self.data_dir):
            print("\n저장된 기록이 없습니다.")
            return

        files = [f for f in os.listdir(self.data_dir) if f.startswith("health_") and f.endswith(".txt")]

        if not files:
            print("\n저장된 기록이 없습니다.")
            return

        files.sort(reverse=True)  # 최신 파일이 먼저 오도록 정렬

        print("\n[저장된 기록 파일]")
        for i, filename in enumerate(files, 1):
            print(f"{i}. {filename}")

        # 파일 선택
        try:
            choice = input("\n조회할 파일 번호를 입력하세요 (0: 취소): ")
            choice = int(choice)

            if choice == 0:
                return

            if 1 <= choice <= len(files):
                filepath = os.path.join(self.data_dir, files[choice - 1])
                self.display_file_records(filepath)
            else:
                print("\n[오류] 잘못된 번호입니다.")

        except ValueError:
            print("\n[오류] 숫자를 입력해주세요.")

    def display_file_records(self, filepath):
        """파일에서 기록을 읽어서 출력"""
        try:
            with open(filepath, "r", encoding="UTF-8") as f:
                lines = f.readlines()

            if not lines:
                print("\n파일이 비어있습니다.")
                return

            print("\n" + "-" * 50)
            print(f"파일: {os.path.basename(filepath)}")
            print("-" * 50)

            for i, line in enumerate(lines, 1):
                health_data = HealthData.from_string(line)
                if health_data:
                    print(f"\n[기록 #{i}]")
                    print(f"  날짜: {health_data.date}")
                    print(f"  이름: {health_data.name}")
                    print(f"  키/몸무게: {health_data.height}cm / {health_data.weight}kg")
                    print(f"  BMI: {health_data.calculate_bmi()} ({health_data.get_bmi_status()})")
                    print(f"  혈압: {health_data.systolic}/{health_data.diastolic} mmHg ({health_data.get_blood_pressure_status()})")

            print("-" * 50)

        except Exception as e:
            print(f"\n[오류] 파일을 읽을 수 없습니다: {e}")

    def show_menu(self):
        """메인 메뉴 출력"""
        print("\n" + "="*50)
        print("     건강 상태 체크 & 관리 시스템")
        print("="*50)
        print("1. 건강 데이터 입력 및 분석")
        print("2. 히스토리 조회")
        print("3. 도움말")
        print("0. 종료")
        print("="*50)

    def show_help(self):
        """도움말 출력"""
        print("\n" + "="*50)
        print("       도움말")
        print("="*50)
        print("\n[BMI (체질량지수) 기준]")
        print("  - 저체중: 18.5 미만")
        print("  - 정상: 18.5 ~ 23 미만")
        print("  - 과체중: 23 ~ 25 미만")
        print("  - 비만 1단계: 25 ~ 30 미만")
        print("  - 비만 2단계: 30 ~ 35 미만")
        print("  - 비만 3단계: 35 이상")

        print("\n[혈압 기준]")
        print("  - 저혈압: 수축기 90 미만 또는 이완기 60 미만")
        print("  - 정상: 수축기 120 미만, 이완기 80 미만")
        print("  - 주의: 수축기 120-129, 이완기 80-84")
        print("  - 고혈압 전단계: 수축기 130-139 또는 이완기 85-89")
        print("  - 고혈압 1단계: 수축기 140-159 또는 이완기 90-99")
        print("  - 고혈압 2단계: 수축기 160-179 또는 이완기 100-109")
        print("  - 고혈압 3단계: 수축기 180 이상 또는 이완기 110 이상")

        print("\n[기록 저장]")
        print("  - 모든 건강 기록은 자동으로 날짜별 파일에 저장됩니다.")
        print("  - 저장 위치: health_records 폴더")
        print("  - 파일명: health_YYYYMMDD.txt")
        print("="*50)

    def run(self):
        """프로그램 실행"""
        print("\n환영합니다! 건강 상태 체크 & 관리 시스템입니다.")

        while True:
            self.show_menu()
            choice = input("\n메뉴를 선택하세요: ")

            if choice == "1":
                # 건강 데이터 입력 및 분석
                health_data = self.input_health_data()
                if health_data:
                    self.display_analysis(health_data)

                    # 저장 여부 확인
                    save = input("\n이 기록을 저장하시겠습니까? (y/n): ")
                    if save.lower() == 'y':
                        self.save_record(health_data)

            elif choice == "2":
                # 히스토리 조회
                self.view_history()

            elif choice == "3":
                # 도움말
                self.show_help()

            elif choice == "0":
                print("\n프로그램을 종료합니다. 건강하세요!")
                break

            else:
                print("\n[오류] 잘못된 메뉴입니다. 다시 선택해주세요.")


def main():
    """메인 함수"""
    manager = HealthManager()
    manager.run()


if __name__ == "__main__":
    main()
