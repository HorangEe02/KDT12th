"""
health_gui.py
건강 상태 체크 시스템 GUI

Author: KDT12 Python Project
Date: 2026-01-09
"""

from tkinter import *
from tkinter import ttk, messagebox
from .health_checker import HealthChecker
from .data_manager import HealthDataManager


class HealthCheckApp(Toplevel):
    """건강 상태 체크 시스템 GUI (Toplevel 기반)"""
    
    def __init__(self, parent=None, base_path=None):
        """생성자: GUI 초기화"""
        super().__init__(parent)

        self.title("💓 건강 상태 체크 시스템")
        self.geometry("1200x850")
        self.resizable(True, True)
        self.minsize(1000, 750)
        
        # 색상 테마
        self.colors = {
            "bg": "#f0f4f8",
            "header": "#27ae60",
            "primary": "#2ecc71",
            "secondary": "#3498db",
            "dark": "#2c3e50",
            "light": "#ecf0f1",
            "white": "#ffffff",
            "danger": "#e74c3c",
            "warning": "#f39c12"
        }
        
        self.configure(bg=self.colors["bg"])
        
        # 데이터 매니저 초기화
        self.data_manager = HealthDataManager(base_path)
        
        # 위젯 생성
        self.create_widgets()
        
        # 창 닫기 이벤트
        self.protocol("WM_DELETE_WINDOW", self.on_close)
    
    def on_close(self):
        """창 닫기"""
        self.destroy()
    
    def create_widgets(self):
        """모든 위젯 생성"""
        # 헤더
        header = Frame(self, bg=self.colors["header"], height=60)
        header.pack(fill=X)
        header.pack_propagate(False)
        
        Label(
            header,
            text="💓 건강 상태 체크 시스템",
            font=("맑은 고딕", 16, "bold"),
            fg=self.colors["white"],
            bg=self.colors["header"]
        ).pack(side=LEFT, padx=20, pady=15)
        
        Button(
            header,
            text="✕ 닫기",
            font=("맑은 고딕", 10),
            bg=self.colors["header"],
            fg=self.colors["white"],
            relief=FLAT,
            cursor="hand2",
            command=self.on_close
        ).pack(side=RIGHT, padx=20)
        
        # 메인 컨텐츠
        main_frame = Frame(self, bg=self.colors["bg"])
        main_frame.pack(fill=BOTH, expand=True, padx=15, pady=10)
        
        # 좌측: 입력 폼
        left_frame = Frame(main_frame, bg=self.colors["white"], relief=GROOVE, bd=1)
        left_frame.pack(side=LEFT, fill=BOTH, expand=True, padx=(0, 5))
        self.create_input_form(left_frame)
        
        # 우측: 결과
        right_frame = Frame(main_frame, bg=self.colors["white"], relief=GROOVE, bd=1)
        right_frame.pack(side=RIGHT, fill=BOTH, expand=True, padx=(5, 0))
        self.create_result_panel(right_frame)
        
        # 하단 버튼
        btn_frame = Frame(self, bg=self.colors["bg"], pady=10)
        btn_frame.pack(fill=X, padx=15)
        
        buttons = [
            ("🔍 분석하기", self.analyze, self.colors["primary"]),
            ("💾 기록 저장", self.save_record, self.colors["secondary"]),
            ("📋 기록 보기", self.show_history, "#9b59b6"),
            ("📊 통계 보기", self.show_statistics, self.colors["dark"]),
            ("🔄 초기화", self.reset, self.colors["light"])
        ]

        for text, command, color in buttons:
            fg = self.colors["dark"] if color == self.colors["light"] else self.colors["white"]
            Button(
                btn_frame,
                text=text,
                font=("맑은 고딕", 15, "bold"),
                bg=color,
                fg=fg,
                relief=FLAT,
                cursor="hand2",
                command=command
            ).pack(side=LEFT, padx=5, ipadx=18, ipady=8)
    
    def create_input_form(self, parent):
        """입력 폼 생성"""
        Label(
            parent,
            text="📝 건강 정보 입력",
            font=("맑은 고딕", 18, "bold"),
            bg=self.colors["white"],
            fg=self.colors["dark"]
        ).pack(pady=(15, 10))

        form_frame = Frame(parent, bg=self.colors["white"])
        form_frame.pack(fill=X, padx=20)

        # 이름
        Label(form_frame, text="이름:", font=("맑은 고딕", 13, "bold"),
              bg=self.colors["white"], fg=self.colors["dark"]).grid(row=0, column=0, pady=5, sticky=E)
        self.name_entry = Entry(form_frame, font=("맑은 고딕", 13), width=18)
        self.name_entry.grid(row=0, column=1, pady=5, padx=5, sticky=W)

        # 나이
        Label(form_frame, text="나이:", font=("맑은 고딕", 13, "bold"),
              bg=self.colors["white"], fg=self.colors["dark"]).grid(row=1, column=0, pady=5, sticky=E)
        self.age_entry = Entry(form_frame, font=("맑은 고딕", 13), width=8)
        self.age_entry.grid(row=1, column=1, pady=5, padx=5, sticky=W)
        Label(form_frame, text="세", font=("맑은 고딕", 13),
              bg=self.colors["white"], fg=self.colors["dark"]).grid(row=1, column=2, sticky=W)
        
        # 성별
        Label(form_frame, text="성별:", font=("맑은 고딕", 10), bg=self.colors["white"]).grid(row=2, column=0, pady=5, sticky=E)
        self.gender_var = StringVar(value="남성")
        gender_frame = Frame(form_frame, bg=self.colors["white"])
        gender_frame.grid(row=2, column=1, pady=5, sticky=W)
        Radiobutton(gender_frame, text="남성", variable=self.gender_var, value="남성", bg=self.colors["white"]).pack(side=LEFT)
        Radiobutton(gender_frame, text="여성", variable=self.gender_var, value="여성", bg=self.colors["white"]).pack(side=LEFT)
        
        # 키
        Label(form_frame, text="키:", font=("맑은 고딕", 10), bg=self.colors["white"]).grid(row=3, column=0, pady=5, sticky=E)
        self.height_entry = Entry(form_frame, font=("맑은 고딕", 10), width=8)
        self.height_entry.grid(row=3, column=1, pady=5, padx=5, sticky=W)
        Label(form_frame, text="cm", font=("맑은 고딕", 10), bg=self.colors["white"]).grid(row=3, column=2, sticky=W)
        
        # 몸무게
        Label(form_frame, text="몸무게:", font=("맑은 고딕", 10), bg=self.colors["white"]).grid(row=4, column=0, pady=5, sticky=E)
        self.weight_entry = Entry(form_frame, font=("맑은 고딕", 10), width=8)
        self.weight_entry.grid(row=4, column=1, pady=5, padx=5, sticky=W)
        Label(form_frame, text="kg", font=("맑은 고딕", 10), bg=self.colors["white"]).grid(row=4, column=2, sticky=W)
        
        # 혈압
        Label(form_frame, text="수축기 혈압:", font=("맑은 고딕", 10), bg=self.colors["white"]).grid(row=5, column=0, pady=5, sticky=E)
        self.ap_hi_entry = Entry(form_frame, font=("맑은 고딕", 10), width=8)
        self.ap_hi_entry.grid(row=5, column=1, pady=5, padx=5, sticky=W)
        Label(form_frame, text="mmHg", font=("맑은 고딕", 10), bg=self.colors["white"]).grid(row=5, column=2, sticky=W)
        
        Label(form_frame, text="이완기 혈압:", font=("맑은 고딕", 10), bg=self.colors["white"]).grid(row=6, column=0, pady=5, sticky=E)
        self.ap_lo_entry = Entry(form_frame, font=("맑은 고딕", 10), width=8)
        self.ap_lo_entry.grid(row=6, column=1, pady=5, padx=5, sticky=W)
        Label(form_frame, text="mmHg", font=("맑은 고딕", 10), bg=self.colors["white"]).grid(row=6, column=2, sticky=W)
        
        # 콜레스테롤
        Label(form_frame, text="콜레스테롤:", font=("맑은 고딕", 10), bg=self.colors["white"]).grid(row=7, column=0, pady=5, sticky=E)
        self.chol_var = StringVar(value="정상")
        chol_combo = ttk.Combobox(form_frame, textvariable=self.chol_var, values=["정상", "높음", "매우 높음"], width=10, state="readonly")
        chol_combo.grid(row=7, column=1, pady=5, padx=5, sticky=W)
        
        # 혈당
        Label(form_frame, text="혈당:", font=("맑은 고딕", 10), bg=self.colors["white"]).grid(row=8, column=0, pady=5, sticky=E)
        self.gluc_var = StringVar(value="정상")
        gluc_combo = ttk.Combobox(form_frame, textvariable=self.gluc_var, values=["정상", "높음", "매우 높음"], width=10, state="readonly")
        gluc_combo.grid(row=8, column=1, pady=5, padx=5, sticky=W)
        
        # 생활습관
        Label(form_frame, text="생활습관:", font=("맑은 고딕", 10, "bold"), bg=self.colors["white"]).grid(row=9, column=0, columnspan=3, pady=(15, 5), sticky=W)
        
        habit_frame = Frame(form_frame, bg=self.colors["white"])
        habit_frame.grid(row=10, column=0, columnspan=3, pady=5, sticky=W)
        
        self.smoke_var = IntVar(value=0)
        self.alco_var = IntVar(value=0)
        self.active_var = IntVar(value=1)
        
        Checkbutton(habit_frame, text="흡연", variable=self.smoke_var, bg=self.colors["white"]).pack(side=LEFT, padx=10)
        Checkbutton(habit_frame, text="음주", variable=self.alco_var, bg=self.colors["white"]).pack(side=LEFT, padx=10)
        Checkbutton(habit_frame, text="운동", variable=self.active_var, bg=self.colors["white"]).pack(side=LEFT, padx=10)
    
    def create_result_panel(self, parent):
        """결과 패널 생성"""
        Label(
            parent,
            text="📊 분석 결과",
            font=("맑은 고딕", 18, "bold"),
            bg=self.colors["white"],
            fg=self.colors["dark"]
        ).pack(pady=(15, 10))
        
        result_frame = Frame(parent, bg=self.colors["white"])
        result_frame.pack(fill=BOTH, expand=True, padx=15)
        
        # BMI 결과
        self.bmi_frame = self.create_result_card(result_frame, "BMI", "체질량지수")
        self.bmi_frame.pack(fill=X, pady=5)
        
        # 혈압 결과
        self.bp_frame = self.create_result_card(result_frame, "혈압", "혈압 상태")
        self.bp_frame.pack(fill=X, pady=5)
        
        # 위험도 결과
        self.risk_frame = self.create_result_card(result_frame, "위험도", "심혈관 질환 위험도")
        self.risk_frame.pack(fill=X, pady=5)
        
        # 성별 평균 비교
        ttk.Separator(parent, orient=HORIZONTAL).pack(fill=X, padx=15, pady=10)
        
        Label(
            parent,
            text="📈 성별 평균 비교",
            font=("맑은 고딕", 12, "bold"),
            bg=self.colors["white"],
            fg=self.colors["dark"]
        ).pack(anchor=W, padx=15)
        
        self.comparison_frame = Frame(parent, bg=self.colors["light"], relief=GROOVE, bd=1)
        self.comparison_frame.pack(fill=X, padx=15, pady=5)
        
        self.comparison_label = Label(
            self.comparison_frame,
            text="분석 후 성별 평균과 비교 결과가 표시됩니다.",
            font=("맑은 고딕", 9),
            bg=self.colors["light"],
            fg="#7f8c8d",
            justify=LEFT,
            wraplength=350
        )
        self.comparison_label.pack(padx=10, pady=10, anchor=W)
        
        # 건강 조언
        ttk.Separator(parent, orient=HORIZONTAL).pack(fill=X, padx=15, pady=5)
        
        Label(
            parent,
            text="💬 건강 조언",
            font=("맑은 고딕", 12, "bold"),
            bg=self.colors["white"],
            fg=self.colors["dark"]
        ).pack(anchor=W, padx=15)
        
        self.advice_text = Text(
            parent,
            height=4,
            font=("맑은 고딕", 10),
            bg=self.colors["light"],
            relief=FLAT,
            wrap=WORD,
            state=DISABLED
        )
        self.advice_text.pack(fill=X, padx=15, pady=10)
    
    def create_result_card(self, parent, title, subtitle):
        """결과 카드 생성"""
        card = Frame(parent, bg=self.colors["light"], relief=GROOVE, bd=1)

        Label(
            card,
            text=title,
            font=("맑은 고딕", 15, "bold"),
            bg=self.colors["light"],
            fg=self.colors["dark"]
        ).pack(anchor=W, padx=10, pady=(8, 0))

        card.status_label = Label(
            card,
            text="--",
            font=("맑은 고딕", 18, "bold"),
            bg=self.colors["light"],
            fg=self.colors["dark"]
        )
        card.status_label.pack(anchor=W, padx=10)

        card.value_label = Label(
            card,
            text="분석 대기 중...",
            font=("맑은 고딕", 12),
            bg=self.colors["light"],
            fg="#7f8c8d"
        )
        card.value_label.pack(anchor=W, padx=10, pady=(0, 8))

        return card
    
    def get_chol_value(self):
        """콜레스테롤 값 변환"""
        chol_map = {"정상": 1, "높음": 2, "매우 높음": 3}
        return chol_map.get(self.chol_var.get(), 1)
    
    def get_gluc_value(self):
        """혈당 값 변환"""
        gluc_map = {"정상": 1, "높음": 2, "매우 높음": 3}
        return gluc_map.get(self.gluc_var.get(), 1)
    
    def validate_inputs(self):
        """입력값 유효성 검사"""
        try:
            age = int(self.age_entry.get())
            height = int(self.height_entry.get())
            weight = float(self.weight_entry.get())
            ap_hi = int(self.ap_hi_entry.get())
            ap_lo = int(self.ap_lo_entry.get())
            
            if not (0 < age < 120):
                raise ValueError("나이는 1~119 사이여야 합니다.")
            if not (100 < height < 250):
                raise ValueError("키는 100~250cm 사이여야 합니다.")
            if not (20 < weight < 300):
                raise ValueError("몸무게는 20~300kg 사이여야 합니다.")
            if not (50 < ap_hi < 250):
                raise ValueError("수축기 혈압은 50~250 사이여야 합니다.")
            if not (30 < ap_lo < 150):
                raise ValueError("이완기 혈압은 30~150 사이여야 합니다.")
            
            return True
        except ValueError as e:
            messagebox.showerror("입력 오류", str(e) if "사이" in str(e) else "모든 필드를 올바르게 입력하세요.")
            return False
    
    def analyze(self):
        """건강 분석 실행"""
        if not self.validate_inputs():
            return
        
        checker = HealthChecker(
            age=int(self.age_entry.get()),
            gender=self.gender_var.get(),
            height=int(self.height_entry.get()),
            weight=float(self.weight_entry.get()),
            ap_hi=int(self.ap_hi_entry.get()),
            ap_lo=int(self.ap_lo_entry.get()),
            cholesterol=self.get_chol_value(),
            gluc=self.get_gluc_value(),
            smoke=self.smoke_var.get(),
            alco=self.alco_var.get(),
            active=self.active_var.get()
        )
        
        # BMI 분석
        bmi_value, bmi_status, bmi_color = checker.calculate_bmi()
        self.bmi_frame.status_label.config(text=bmi_status, fg=bmi_color)
        self.bmi_frame.value_label.config(text=f"BMI: {bmi_value}", fg=self.colors["dark"])
        
        # 혈압 분석
        bp_status, bp_desc, bp_color = checker.analyze_blood_pressure()
        self.bp_frame.status_label.config(text=bp_status, fg=bp_color)
        self.bp_frame.value_label.config(
            text=f"{self.ap_hi_entry.get()}/{self.ap_lo_entry.get()} mmHg",
            fg=self.colors["dark"]
        )
        
        # 위험도 분석
        risk_score, risk_grade, risk_desc, risk_color = checker.calculate_risk_score()
        self.risk_frame.status_label.config(text=f"{risk_grade} ({risk_score}점)", fg=risk_color)
        self.risk_frame.value_label.config(text=risk_desc, fg=self.colors["dark"])
        
        # 성별 평균 비교
        user_data = checker.to_dict()
        gender = self.gender_var.get()
        comparison = self.data_manager.compare_with_gender_average(user_data, gender)
        
        if comparison:
            comparison_text = f"📊 {gender} 평균 대비 (샘플 {comparison['sample_count']}명)\n\n"
            
            bmi_comp = comparison["bmi"]
            bmi_icon = "🔴" if bmi_comp["status"] == "higher" and bmi_comp["diff"] > 2 else "🟢" if bmi_comp["status"] == "lower" else "🟡"
            comparison_text += f"{bmi_icon} BMI: {bmi_comp['user']} (평균 {bmi_comp['avg']}) → {bmi_comp['text']}\n"
            
            height_comp = comparison["height"]
            comparison_text += f"📏 키: {height_comp['user']}cm (평균 {height_comp['avg']}cm) → {height_comp['text']}\n"
            
            weight_comp = comparison["weight"]
            weight_icon = "🔴" if weight_comp["status"] == "higher" and weight_comp["diff"] > 5 else "🟢" if weight_comp["status"] == "lower" else "🟡"
            comparison_text += f"{weight_icon} 몸무게: {weight_comp['user']}kg (평균 {weight_comp['avg']}kg) → {weight_comp['text']}\n"
            
            bp_comp = comparison["ap_hi"]
            bp_icon = "🔴" if bp_comp["status"] == "higher" and bp_comp["diff"] > 10 else "🟢" if bp_comp["status"] == "lower" else "🟡"
            comparison_text += f"{bp_icon} 수축기 혈압: {bp_comp['user']}mmHg (평균 {bp_comp['avg']}mmHg) → {bp_comp['text']}\n"
            
            comparison_text += f"\n⚠️ {gender} 심혈관 질환 비율: {comparison['cardio_rate']}%"
            
            self.comparison_label.config(text=comparison_text, fg=self.colors["dark"])
        
        # 건강 조언
        advice_list = checker.get_health_advice()
        self.advice_text.config(state=NORMAL)
        self.advice_text.delete(1.0, END)
        for advice in advice_list:
            self.advice_text.insert(END, f"• {advice}\n")
        self.advice_text.config(state=DISABLED)
        
        self.current_checker = checker
    
    def save_record(self):
        """기록 저장"""
        if not hasattr(self, "current_checker"):
            messagebox.showwarning("경고", "먼저 분석을 실행하세요.")
            return
        
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("경고", "이름을 입력하세요.")
            return
        
        data = self.current_checker.to_dict()
        if self.data_manager.save_record(name, data):
            messagebox.showinfo("저장 완료", f"{name}님의 건강 기록이 저장되었습니다.")
        else:
            messagebox.showerror("저장 실패", "기록 저장에 실패했습니다.")
    
    def show_history(self):
        """기록 보기"""
        records = self.data_manager.load_records()
        
        if not records:
            messagebox.showinfo("기록 없음", "저장된 기록이 없습니다.")
            return
        
        popup = Toplevel(self)
        popup.title("📋 건강 기록")
        popup.geometry("700x400")
        popup.transient(self)
        
        columns = ("date", "name", "age", "gender", "bmi", "ap", "risk")
        tree = ttk.Treeview(popup, columns=columns, show="headings", height=15)
        
        tree.heading("date", text="날짜")
        tree.heading("name", text="이름")
        tree.heading("age", text="나이")
        tree.heading("gender", text="성별")
        tree.heading("bmi", text="BMI")
        tree.heading("ap", text="혈압")
        tree.heading("risk", text="위험도")
        
        for col in columns:
            tree.column(col, width=90, anchor=CENTER)
        
        for record in records:
            tree.insert("", END, values=(
                record.get("date", ""),
                record.get("name", ""),
                record.get("age", ""),
                record.get("gender", ""),
                record.get("bmi", ""),
                f"{record.get('ap_hi', '')}/{record.get('ap_lo', '')}",
                record.get("risk_score", "")
            ))
        
        tree.pack(fill=BOTH, expand=True, padx=10, pady=10)
    
    def show_statistics(self):
        """통계 보기"""
        gender_stats = self.data_manager.get_gender_statistics()
        
        if not gender_stats or not gender_stats["total"]:
            messagebox.showinfo("통계 없음", "샘플 데이터가 없습니다.")
            return
        
        popup = Toplevel(self)
        popup.title("📊 Kaggle 데이터 성별 통계")
        popup.geometry("650x450")
        popup.resizable(False, False)
        popup.configure(bg=self.colors["white"])
        popup.transient(self)
        
        Label(
            popup,
            text="📊 Kaggle 심혈관 데이터 - 성별별 통계",
            font=("맑은 고딕", 14, "bold"),
            bg=self.colors["white"]
        ).pack(pady=15)
        
        table_frame = Frame(popup, bg=self.colors["white"])
        table_frame.pack(fill=BOTH, expand=True, padx=20)
        
        headers = ["항목", "👨 남성", "👩 여성", "전체"]
        for col, header in enumerate(headers):
            Label(
                table_frame,
                text=header,
                font=("맑은 고딕", 11, "bold"),
                bg=self.colors["primary"] if col > 0 else self.colors["light"],
                fg=self.colors["white"] if col > 0 else self.colors["dark"],
                width=12,
                relief=RIDGE,
                padx=10,
                pady=8
            ).grid(row=0, column=col, sticky="nsew")
        
        male = gender_stats["male"]
        female = gender_stats["female"]
        total = gender_stats["total"]
        
        stat_items = [
            ("샘플 수", f"{male['total_samples']}명", f"{female['total_samples']}명", f"{total['total_samples']}명"),
            ("평균 나이", f"{male['avg_age']}세", f"{female['avg_age']}세", f"{total['avg_age']}세"),
            ("평균 키", f"{male['avg_height']}cm", f"{female['avg_height']}cm", f"{total['avg_height']}cm"),
            ("평균 몸무게", f"{male['avg_weight']}kg", f"{female['avg_weight']}kg", f"{total['avg_weight']}kg"),
            ("평균 BMI", f"{male['avg_bmi']}", f"{female['avg_bmi']}", f"{total['avg_bmi']}"),
            ("평균 수축기 혈압", f"{male['avg_ap_hi']}mmHg", f"{female['avg_ap_hi']}mmHg", f"{total['avg_ap_hi']}mmHg"),
            ("심혈관 질환율", f"{male['cardio_rate']}%", f"{female['cardio_rate']}%", f"{total['cardio_rate']}%"),
        ]
        
        for row, (label, m_val, f_val, t_val) in enumerate(stat_items, start=1):
            Label(table_frame, text=label, font=("맑은 고딕", 10), bg=self.colors["light"], width=12, relief=RIDGE, pady=5).grid(row=row, column=0, sticky="nsew")
            Label(table_frame, text=m_val, font=("맑은 고딕", 10), bg="#e3f2fd", width=12, relief=RIDGE, pady=5).grid(row=row, column=1, sticky="nsew")
            Label(table_frame, text=f_val, font=("맑은 고딕", 10), bg="#fce4ec", width=12, relief=RIDGE, pady=5).grid(row=row, column=2, sticky="nsew")
            Label(table_frame, text=t_val, font=("맑은 고딕", 10), bg=self.colors["white"], width=12, relief=RIDGE, pady=5).grid(row=row, column=3, sticky="nsew")
    
    def reset(self):
        """초기화"""
        self.name_entry.delete(0, END)
        self.age_entry.delete(0, END)
        self.height_entry.delete(0, END)
        self.weight_entry.delete(0, END)
        self.ap_hi_entry.delete(0, END)
        self.ap_lo_entry.delete(0, END)
        
        self.gender_var.set("남성")
        self.chol_var.set("정상")
        self.gluc_var.set("정상")
        self.smoke_var.set(0)
        self.alco_var.set(0)
        self.active_var.set(1)
        
        self.bmi_frame.status_label.config(text="--", fg=self.colors["dark"])
        self.bmi_frame.value_label.config(text="분석 대기 중...", fg="#7f8c8d")
        self.bp_frame.status_label.config(text="--", fg=self.colors["dark"])
        self.bp_frame.value_label.config(text="분석 대기 중...", fg="#7f8c8d")
        self.risk_frame.status_label.config(text="--", fg=self.colors["dark"])
        self.risk_frame.value_label.config(text="분석 대기 중...", fg="#7f8c8d")
        
        self.comparison_label.config(text="분석 후 성별 평균과 비교 결과가 표시됩니다.", fg="#7f8c8d")
        
        self.advice_text.config(state=NORMAL)
        self.advice_text.delete(1.0, END)
        self.advice_text.config(state=DISABLED)
        
        if hasattr(self, "current_checker"):
            del self.current_checker
